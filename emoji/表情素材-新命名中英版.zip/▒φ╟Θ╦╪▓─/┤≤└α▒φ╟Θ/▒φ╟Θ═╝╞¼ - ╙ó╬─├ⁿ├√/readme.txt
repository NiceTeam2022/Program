此文件夹为英文命名格式
说明：
乐-happy
好-good
怒-angry
哀--sad
惧-fear
恶-hate
惊-scare

表情图片命名规则：
对每个大类的两个强度命名：大类名称-5 大类名称-10